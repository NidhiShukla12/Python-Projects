
# 1.Write a Python program that takes a number as input and prints "Even" if the number is even and "Odd" if it's odd.


# Get user input
number = int(input("Enter a number: "))

# Check if the number is even or odd
if number % 2 == 0:
    print("Even")
else:
    print("Odd")